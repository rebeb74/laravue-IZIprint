<!DOCTYPE html>
<html class="h-full" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e($seo['title'].' '.$seo['suffix']); ?></title>
        <meta name="description" content ="<?php echo e($seo['description']); ?>" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="<?php echo e($seo['title']); ?>" />
        <meta property="og:description" content="<?php echo e($seo['description']); ?>" />
        <meta property="og:url" content="https://iziprint.re" />
        <meta property="og:image" content="<?php echo e($seo['social_image']['thumb_url']); ?>" />
        <meta property="og:determiner" content="auto" />
        <meta property="og:locale" content="fr_FR" />
        <meta property="og:site_name" content="IZIprint" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="<?php echo e($seo['title']); ?>" />
        <meta name="twitter:description" content="<?php echo e($seo['description']); ?>" />
        <meta name="twitter:image" content="<?php echo e($seo['social_image']['thumb_url']); ?>" />

        <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo-light.png')); ?>" />

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body class="h-full bg-primary m-0">
        <div id="app" class="h-full m-0">
            <app class="h-full m-0"/>
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /Users/frimammd14/Desktop/Bertrand PETIT/LaraVue IZIprint/iziprint/resources/views/welcome.blade.php ENDPATH**/ ?>