<template>
  <div class="w-full">
    <h1
      class="
        uppercase
        text-4xl text-secondary
        pt-20
        pb-4
        pl-4
        w-xs
        lg:w-5xl
        m-auto
        font-bold
      "
    >
      à propos de nous
    </h1>
    <div class="bg-primary-gray">
      <div class="w-xs lg:w-5xl m-auto py-8">
        <h2 class="text-secondary-light uppercase text-xl font-bold">
          Notre parcours
        </h2>
        <div
          class="
            text-gray-200
            pb-4
            content-none
            clear-both
            table
            text-justify
            pt-4
          "
        >
          <img
            class="w-72 my-4 mr-6 float-left max-w-72"
            src="../../../assets/logo/logo-500.png"
            alt="Logo IZIprint full"
          />
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
            risus sed vulputate odio. Nunc mi ipsum faucibus vitae. Sagittis id
            consectetur purus ut faucibus pulvinar elementum. Facilisi cras
            fermentum odio eu feugiat pretium nibh ipsum consequat. Enim diam
            vulputate ut pharetra sit. Risus ultricies tristique nulla aliquet
            enim. Morbi tincidunt augue interdum velit euismod in pellentesque
            massa placerat. Gravida cum sociis natoque penatibus et magnis dis.
            Nibh tellus molestie nunc non blandit massa enim nec dui. Cras
            ornare arcu dui vivamus. Netus et malesuada fames ac turpis egestas
            maecenas pharetra. Aliquam ultrices sagittis orci a scelerisque.
            Condimentum lacinia quis vel eros donec ac odio. Sit amet volutpat
            consequat mauris nunc congue nisi. Sapien et ligula ullamcorper
            malesuada proin libero nunc. Orci sagittis eu volutpat odio
            facilisis mauris. Elit sed vulputate mi sit amet mauris commodo
            quis. Felis imperdiet proin fermentum leo vel. Facilisi cras
            fermentum odio eu. Lacus sed turpis tincidunt id aliquet. Dui
            vivamus arcu felis bibendum ut tristique. Mi sit amet mauris commodo
            quis imperdiet massa tincidunt. At tellus at urna condimentum mattis
            pellentesque id nibh. Sed euismod nisi porta lorem mollis aliquam ut
            porttitor leo. Dolor sit amet consectetur adipiscing elit ut aliquam
            purus sit. Faucibus pulvinar elementum integer enim neque volutpat.
          </p>
        </div>
      </div>
    </div>
    <div class="w-xs lg:w-5xl m-auto py-8">
      <h2 class="text-secondary-light uppercase text-xl font-bold">
        Notre équipe à votre service
      </h2>
      <div class="flex justify-between px-4">
        <div class="flex flex-col justify-center items-center py-4">
          <div class="w-48">
            <img
              src="../../../assets/images/avatar1.png"
              alt="Directeur Général Jon Snow"
            />
          </div>
          <div class="py-2 flex flex-col justify-center items-center">
            <p class="text-gray-200">Jon Snow</p>
            <p class="text-gray-200">Directeur</p>
          </div>
        </div>
        <div class="flex flex-col justify-center items-center py-4">
          <div class="w-48">
            <img
              src="../../../assets/images/avatar2.png"
              alt="Directeur Général Jon Snow"
            />
          </div>
          <div class="py-2 flex flex-col justify-center items-center">
            <p class="text-gray-200">Mary Poppins</p>
            <p class="text-gray-200">Graphiste</p>
          </div>
        </div>
        <div class="flex flex-col justify-center items-center py-4">
          <div class="w-48">
            <img
              src="../../../assets/images/avatar3.png"
              alt="Directeur Général Jon Snow"
            />
          </div>
          <div class="py-2 flex flex-col justify-center items-center">
            <p class="text-gray-200">Soeur Marie Thérèse</p>
            <p class="text-gray-200">Impression</p>
          </div>
        </div>
        <div class="flex flex-col justify-center items-center py-4">
          <div class="w-48">
            <img
              src="../../../assets/images/avatar4.png"
              alt="Directeur Général Jon Snow"
            />
          </div>
          <div class="py-2 flex flex-col justify-center items-center">
            <p class="text-gray-200">Flash</p>
            <p class="text-gray-200">Apprentie</p>
          </div>
        </div>
      </div>
    </div>
    <div class="bg-primary-gray">
      <div class="w-xs lg:w-5xl m-auto py-8">
        <h2 class="text-secondary-light uppercase text-xl font-bold pb-4">
          No machines
        </h2>
        <div class="flex flex-col lg:flex-row space-x-2">
          <div class="w-80 flex flex-col justify-center items-center">
            <img
              src="../../../assets/images/impression1.jpg"
              alt="Imprimante 1"
            />
            <p class="text-gray-200">Imprimante 1</p>
          </div>
          <div class="w-80 flex flex-col justify-center items-center">
            <img
              src="../../../assets/images/impression2.jpg"
              alt="Imprimante 2"
            />
            <p class="text-gray-200">Imprimante 2</p>
          </div>
          <div class="w-80 flex flex-col justify-center items-center">
            <img src="../../../assets/images/decoupe1.jpg" alt="Découpe 1" />
            <p class="text-gray-200">Découpe 1</p>
          </div>
          <div class="w-80 flex flex-col justify-center items-center">
            <img src="../../../assets/images/decoupe2.jpg" alt="Découpe 2" />
            <p class="text-gray-200">Découpe 2</p>
          </div>
        </div>
      </div>
    </div>
    <div>
      <div class="w-xs lg:w-5xl m-auto py-8">
        <h2 class="text-secondary-light uppercase text-xl font-bold pb-4">
          Nos Locaux
        </h2>
        <div class="flex justify-between">
          <div class="w-96 flex flex-col justify-center items-center space-y-8">
            <img
              src="../../../assets/images/vehicule_iziprint.jpg"
              alt="Véhicule iziprint"
            />
            <div>
              <p class="text-gray-200 text-center">
                82 rue des papangues 97480 Saint-Joseph
              </p>
              <p class="text-gray-200 text-center">La Réunion</p>
            </div>
          </div>
          <div>
            <div class="mapouter">
              <div class="gmap_canvas">
                <iframe
                  width="600"
                  height="350"
                  id="gmap_canvas"
                  src="https://maps.google.com/maps?q=-21.364321402654628,%2055.664620798882574&t=&z=13&ie=UTF8&iwloc=&output=embed"
                  frameborder="0"
                  scrolling="no"
                  marginheight="0"
                  marginwidth="0"
                ></iframe
                ><style>
                  .gmap_canvas {
                    overflow: hidden;
                    background: none !important;
                    height: 350px;
                    width: 600px;
                  }
                </style>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-for="(block, index) in currentPage.blocks" :key="block.id">
      <div v-if="block.enabled" :class="bgColor(index)">
        <block-preview
          :block="block"
          class="m-auto w-xs lg:w-5xl py-5 lg:px-5"
        ></block-preview>
      </div>
    </div>
    <div v-if="currentPage.gallery.length > 0">
      <image-gallery :images="currentPage.gallery"></image-gallery>
    </div>
  </div>
</template>

<script>
import indexMixin from "./mixins/indexMixin.js";

export default {
  mixins: [indexMixin],
  data() {
    return {
      nbInitialBlocks: 4,
    };
  },
  methods: {
    bgColor(index) {
      if (this.nbInitialBlocks % 2) {
        if (!(index % 2)) {
          return "w-full bg-primary-gray ";
        }
      } else {
        if (index % 2) {
          return "w-full bg-primary-gray ";
        }
      }
    },
  },
};
</script>