<template>
  <div class="">
    <div class="bg lg:bg-no-repeat lg:bg-top w-full z-0">
      <div
        class="
          m-auto
          w-xs
          lg:w-5xl
          py-5
          lg:px-5
          z-10
          flex flex-col
          justify-start
          items-center
          relative
        "
      >
        <!-- Small screen logo -->
        <img
          class="w-72 my-16 mr-12 lg:hidden"
          src="../../../assets/logo/logo-500.png"
          alt="Logo IZIprint full"
        />
        <!-- Large screen -->
        <div class="py-10 my-16 hidden lg:block">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            width="499"
            height="427.627"
            viewBox="0 0 499 427.627"
          >
            <defs>
              <linearGradient
                id="linear-gradient"
                x1="1"
                y1="0.5"
                x2="0"
                y2="0.5"
                gradientUnits="objectBoundingBox"
              >
                <stop offset="0" stop-color="#fff" />
                <stop offset="0.803" stop-color="#9c9b9b" />
              </linearGradient>
              <linearGradient
                id="linear-gradient-2"
                x1="-0.01"
                y1="0.01"
                x2="1.007"
                y2="0.993"
                gradientUnits="objectBoundingBox"
              >
                <stop offset="0" stop-color="#bd1622" />
                <stop offset="1" stop-color="#e20613" />
              </linearGradient>
              <filter
                id="Rectangle_16"
                x="42.359"
                y="155.902"
                width="89.801"
                height="15.588"
                filterUnits="userSpaceOnUse"
              >
                <feOffset dx="1.957" dy="1.957" input="SourceAlpha" />
                <feGaussianBlur stdDeviation="0.979" result="blur" />
                <feFlood flood-color="#1d1d1b" flood-opacity="0.502" />
                <feComposite operator="in" in2="blur" />
                <feComposite in="SourceGraphic" />
              </filter>
              <filter
                id="Rectangle_17"
                x="42.359"
                y="165.619"
                width="89.801"
                height="18.906"
                filterUnits="userSpaceOnUse"
              >
                <feOffset dx="1.957" dy="1.957" input="SourceAlpha" />
                <feGaussianBlur stdDeviation="0.979" result="blur-2" />
                <feFlood flood-color="#1d1d1b" flood-opacity="0.502" />
                <feComposite operator="in" in2="blur-2" />
                <feComposite in="SourceGraphic" />
              </filter>
              <linearGradient
                id="linear-gradient-3"
                x1="-0.429"
                y1="-0.8"
                x2="1.537"
                y2="1.951"
                gradientUnits="objectBoundingBox"
              >
                <stop offset="0" stop-color="#f5f5f5" />
                <stop offset="0.912" stop-color="#6f6f6e" />
              </linearGradient>
              <linearGradient
                id="linear-gradient-4"
                x1="-1.228"
                y1="-0.838"
                x2="0.738"
                y2="0.684"
                xlink:href="#linear-gradient-3"
              />
              <linearGradient
                id="linear-gradient-5"
                x1="-0.888"
                y1="-0.491"
                x2="-0.025"
                y2="0.125"
                gradientUnits="objectBoundingBox"
              >
                <stop offset="0.01" stop-color="#ececec" />
                <stop offset="0.151" stop-color="#e0e0df" />
                <stop offset="0.406" stop-color="silver" />
                <stop offset="0.743" stop-color="#8d8d8c" />
                <stop offset="0.926" stop-color="#6f6f6e" />
              </linearGradient>
              <linearGradient
                id="linear-gradient-6"
                x1="-0.069"
                y1="-0.244"
                x2="0.794"
                y2="0.884"
                xlink:href="#linear-gradient-5"
              />
              <radialGradient
                id="radial-gradient"
                cx="0.36"
                cy="0.268"
                r="0.964"
                gradientTransform="translate(0)"
                gradientUnits="objectBoundingBox"
              >
                <stop offset="0" stop-color="#fff" />
                <stop offset="0.065" stop-color="#d4e6f3" />
                <stop offset="0.129" stop-color="#b2d2ea" />
                <stop offset="0.19" stop-color="#99c3e4" />
                <stop offset="0.246" stop-color="#8bbbe0" />
                <stop offset="0.292" stop-color="#86b8df" />
                <stop offset="0.646" stop-color="#556cac" />
              </radialGradient>
            </defs>
            <g
              id="Groupe_26"
              data-name="Groupe 26"
              transform="translate(-160.059 -25.741)"
            >
              <path
                id="Tracé_1042"
                data-name="Tracé 1042"
                d="M353.72,341.987c-1.818.367-3.692.713-5.638,1.027a154.235,154.235,0,0,1-48.275.33,157.949,157.949,0,0,1-58.763-21.475,157.4,157.4,0,0,1-52.214-52.393c-.915-1.388-1.691-2.865-2.517-4.308q-1.22-2.2-2.452-4.4c-.741-1.5-1.495-3.007-2.248-4.523l-1.136-2.274c-.3-.641-.674-1.549-1.017-2.3-.7-1.589-1.386-3.182-2.086-4.788-.676-1.589-1.219-3.186-1.846-4.775-1.273-3.156-2.26-6.493-3.344-9.807a156.613,156.613,0,0,1-4.73-20.581c-.657-3.5-.964-7.064-1.387-10.628-.181-1.79-.251-3.588-.379-5.388l-.172-2.7-.044-2.714A158.519,158.519,0,0,1,187.988,104.9a165.259,165.259,0,0,1,13.234-18.752,161.007,161.007,0,0,1,15.944-16.706,162.986,162.986,0,0,1,18.322-14.223,156.472,156.472,0,0,1,42.05-19.632,156.287,156.287,0,0,1,68.773-4.533,159.56,159.56,0,0,1,65.422,26.118,15.983,15.983,0,0,0-.334-3.444A162.429,162.429,0,0,0,346.826,27.9a168.942,168.942,0,0,0-23.431-2.129,165.649,165.649,0,0,0-23.63,1.349,167.716,167.716,0,0,0-23.284,4.874l-5.694,1.769c-1.9.551-3.757,1.344-5.643,2-3.841,1.319-7.287,2.954-11.017,4.507a174.885,174.885,0,0,0-20.892,11.513,159.43,159.43,0,0,0-35.469,31.505A170.1,170.1,0,0,0,184,102.479a163.631,163.631,0,0,0-23.913,87.915l.033,2.807.156,2.8c.125,1.851.177,3.718.35,5.571.407,3.692.7,7.385,1.345,11.014a161.617,161.617,0,0,0,4.742,21.343c1.091,3.441,2.085,6.887,3.407,10.245.634,1.679,1.219,3.4,1.89,5.028.69,1.6,1.372,3.2,2.055,4.795.353.824.638,1.528,1.057,2.452l1.163,2.369c.76,1.577,1.533,3.156,2.3,4.712.836,1.525,1.676,3.054,2.5,4.568.843,1.516,1.639,3.049,2.575,4.5a165.112,165.112,0,0,0,24.589,31.581,168.361,168.361,0,0,0,29.3,23.336A164.938,164.938,0,0,0,298.72,350.4a161.4,161.4,0,0,0,50.554.044c.45-.067.9-.137,1.333-.209"
                transform="translate(0)"
                fill="url(#linear-gradient)"
              />
              <g
                id="Groupe_9"
                data-name="Groupe 9"
                transform="translate(175.034 30.019)"
              >
                <path
                  id="Tracé_1043"
                  data-name="Tracé 1043"
                  d="M183.869,51.84c2.585,12.9,5.847,25.358,7.4,38.014,1.284,10.448-3.24,15.27-13.789,17.534-2.838-11.427-6.235-22.794-8.348-34.37C166.943,60.931,171.2,55.191,183.869,51.84Z"
                  transform="translate(-168.585 -10.28)"
                  fill="#35a8e0"
                  fill-rule="evenodd"
                />
                <path
                  id="Tracé_1044"
                  data-name="Tracé 1044"
                  d="M194.266,40.007c2.591,12.911,5.852,25.356,7.4,38.012,1.3,10.445-3.232,15.259-13.785,17.53-2.824-11.434-6.224-22.781-8.337-34.366C177.342,49.1,181.6,43.362,194.266,40.007Z"
                  transform="translate(-160.716 -19.23)"
                  fill="#ffec00"
                  fill-rule="evenodd"
                />
                <path
                  id="Tracé_1045"
                  data-name="Tracé 1045"
                  d="M204.667,28.177c2.6,12.9,5.85,25.358,7.4,38,1.284,10.452-3.235,15.273-13.787,17.546-2.826-11.434-6.235-22.778-8.337-34.37C187.743,37.268,192,31.528,204.667,28.177Z"
                  transform="translate(-152.848 -28.177)"
                  fill="#e5007e"
                  fill-rule="evenodd"
                />
              </g>
              <g
                id="Groupe_12"
                data-name="Groupe 12"
                transform="translate(291.985 90.887)"
              >
                <image
                  id="Rectangle_15"
                  data-name="Rectangle 15"
                  width="273.989"
                  height="282.77"
                  opacity="0.5"
                  xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJwAAAChCAYAAAAyXNY+AAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAnKADAAQAAAABAAAAoQAAAAAVrtHVAAAPM0lEQVR4Ae2dDXvjRhWFN9AtFFoobYGW/XJa/v8/WuKEwPaDAoVCgS0bzivPMRNFsmPJnkije5/nZiRZ1miOXt+ZKzmes5ubm0dd9vz507Ou7bFtmQpcXV13g3KgHGdt4DLQDJzLAw8du1eigEFryrHg3QIuwQZgP8ic9YCuEnoObAaQ4W8yvxkD3Ra4BBug/VD+OHPW2R7QSYQFmUH7r9r8OnPW3wyFrgEui2xv6WA/kv9E/tPkrLM9Ip1EWIg5sn2v9v5b/o/k/0zrbB8U6QDJRhQjsgHbB/KPUvmeSqBzlItIJzEqNsNGNwpsf5f/Wf4nOebulUh3sJ09e/bEkQv4gO1D+RP5s1QCH9uBMWCTCAswoKMbJaIB2x/kv0/l1yrZPijK7YpwQPep/GM5Ue5tueHUYlilCjjC/UftI7p9ntpJt/oX+d/k9HaDzMAZJBIEus935UQ2YHsq/7kc4NytajGsUgUAjm4T4L5JbfyrSpiADRgxL+x7kBk43sRBAIptHJhulMgGbO/L83GcVsMqVcDAMX7DgA4WuP6wMSro5MDpWFtyoZjXiGo4lQVwEmEBZuBoqq8/LOSRbbAMbeA4kMOlS4jOne1h9SrgbtLX3By4HNXyLuB8QFfQVXqfKOtU4GTXHIrDQoFiCgRwxaSOilAggAsOiioQwBWVOyoL4IKBogoEcEXljsoCuGCgqAIBXFG5o7IALhgoqkAAV1TuqCyACwaKKhDAFZU7KgvggoGiCgRwReWOygK4YKCoAgFcUbmjsgAuGCiqQABXVO6oLIALBooqEMAVlTsqC+CCgaIKBHBF5Y7KArhgoKgCAVxRuaOyAC4YKKpAAFdU7qgsgAsGiioQwBWVOyoL4IKBogoEcEXljsoCuGCgqAIBXFG5o7IALhgoqkAAV1TuqCyACwaKKrDrN375ceEuL3qCE6+M38INO0CBLuDakHluJUosRL6rQa2atFnYEDDibxs4V8DEXcylxGwkuCeJoAuuVVw1ba/Rdjta5HrUpIs5oHTAybftFapvhxw4HxzQAIwJvJhrydPfLHnqI8NkyNCNye4ocSbNwLzfZm2efw2Wgw482Nnm1we1zsD5IBwQ2L6VM4ucJ/YCOoDzp1uLizG3GdjQCx1+LGc6oHfSMvsYOi3O1hx04ICe7V9yJnUj+LDMDIOjoDNwOk4TOttTFrKdib2WOH2loxWgARMRDdCYuJj5x34hx3gNZz/M79uszeMvoGF0n0Qzg8a1ZwZBnN6O7bzu/bV4mL3FVNKaEZp3URnAEd2+knNQlpc6Qa8jm6MaHzpAYz5ZtCHSEeH8idfiLI224DlsTFHJhLz0cH+UfyEHOiIdjLDv6BmhDRwHxehaIdyzyPkC8FrtRlsd2YhqTN1IROPCABmis4zNMaJtznzTBtqRd6GGjUl51/JL+Ss5Qyy6VyIcrAyypkvNohwVAxoHpCSMuruYs7Bqxr3NsKENHzYiPPAR3dgGcHSrlLxufbQ4K3NU8zUn0DBWJ7IR1QDtd6kk0hF8tl0qzGj9YGuA410JOkDzifApRmguwBJgcxtpM7oQ2ShxAGPC4l8lp1v9mRzoGNvNTSdfY6JVniR+qXUi21XmwPe1nOEVicSoIcTZzc1tUDWes/DtUnVVa7QVz2Ejsn0kZ4C7kn+WyicqAY7XgdLA8d6pmy82gQXYiFj0YgBFt5mDBnhfyBm7ARv7AtubodFN7310Bzg2Yhl4mw31/jVsdI0kAkBE9AIq4FrJDRvwASGw0Z0S/QDNx9DiZA3Y8shm2OhCgetSfpFKohrb6WLpaomCo2HTMfqB48XaLX2oAAbYAMiZKFD9Rv5Cfi5fyYHPsLm7dVQDuCmbYQMa318jOSCyAdtaDmyUrLOd14Fy242OiWw6TmN8QhdpGWxoAGzORH+tZeB6nvknWjZs7JtHNq1O2oCNLhTYiFRdyQGwEeGAjchGN8u+r+XNuP4YsOlYjXCUi7IO2OgiAQqwctAADwC5JQKQc4UtTw4YkzE2A658zPZK60Q2YCOy8R5gaxJKymPY4iJcCza6RsMGXCv5ufyFnC4VCLkdQlcLbHS9HrNpcdLmyGbYAInoBVg5aIBHdsp9tm/lRLYGtmNFNR1va4sBLoFGwwGGduewPdU6oDk5AD6SBpIH9iOZALaz5Coma4CGEZ0Ap50crLXNXejJkgPV0WmLAC7BBizA9lhOtHJky2EDOtY9XsuTg7nAlke2HLZrtWstf5lKIhtd6EmSAx2306oHLoONCLXrtscu2BAP4KZsgIbvykQNG/CdNDnoE6pq4LLxGrAR1Ybc9pg6aFxbR7V9meha+xLZDNvJkgPV0WnVApfBRhuBjSyTbLPW2x6M1xjwM/AnASARAK48QXildcN20uRA9XRalcB1wObxWk23PYhqWDs5YFwGWDlogJc/pnoQ2HQOdd2HS6DRrq5MtKbbHh6vtWEjegHXpfwilcUzUdXba9VEuAQb462+THSl12q57QFwu5IDYFvLga94Jqo6e60K4DLY9mWiKykx99seRLV9yQERDtjy8dprrfPeQd/U1fuOYrMHLhuvjclEEXPq2ShRzV3ofZIDIttJH1Mh2qE2a+Ay2GhHrZkooGGGzTdz+5KDYo+pNqd12N/ZAtcB23tqOk8IastE88hm2CafHPRhOEvgWrDlz0RrzERnmRxUAVwCjbZ03fbIn4mutM/cH8DPOjngInXZbCJcgm3XbY9zNZDbHpQ1ZKL5k4MH/Q5bFzhDt80CuAy2fbc9dsGGRgA7ZcvHa2Sik/gO2zEFmzxw2XhtzG2POYDGdW1nok4O1nrtQn4pn9STA53PQTZp4DLYOM+ab3vkkS3PRK/V7rX8ZSon9+RA53WQTRa4Dthqvu2xKxM1bMA3uScHB9GmnScHXAKNdnRlorXd9rhPJrqWFvljquLfYeNiHMsmBVyCjfHWEh7Ae7x2n8dUeWQjex313+/HgmfIcSYDXAbbvkx0pYbO9bYHYzXMsHm81veYahLfYduc8nH+TgK4bLw2JhNFkSlno8DWlxzQZZKBXqRy1pmo2tBrDw5cBhvnUnsmuis5ALa1fPaZqNrQaw8KXAdstWai90kOiHB5csDYbhLfYeulZ8ALDwZcC7aaH8B7vHaf5ICx3OS+wzaAq963FAcugcYJdd32IBk4l38mX8nn+gCesRpm2PYlB5P+DtumKcf5WxS4BNuZTr3vtodho5xzJrr45KAPz2LAZbDtu+2xCzbaAbBTNUDDF58c9F2gIsBl47Uxtz2mDBr6OqoBG+O1B/0dNk5oinZy4DLYqKvm2x4er0VysIP0kwLXAVtttz2Iaphhi+Rgo0fv35MAl0Cj0q5MtJYH8B6vtWHzd9gu1f4LOWW1Tw7UtoPs6MAl2Bhv9WWiK71Ww20PgIvkQCIcYkcFLoNtXya60knO+bYHUS2Sg0NIS/seDbhsvDYmE+W0ppyNEtXchTo5qOYfXBITJy2OAlwGG8dbSiZa3T+4nJS0dPDemWjuW3kHbLVlokjhyEY36kzUycFa2/YmB+kYKuq3Xb9+Pgq4Dtj41W9+bqGWTBQ6DNv3WqYbJbLxkP1avpa/TGXv14r0OsdYgrmdTdkF3mDgEmyMt+hG/W2PX2q5lgfwAIJwuGFjvlBg4zbHWm7YgM9fAycCsj9jPb9fi9Wb2+p2U+K3JhYBlqEGbM5Gmd7xQzmR7Vz+21QC31x/gl6n3hiiGTh+P5d5Q4ELJ2FgG6+jhX9m36Jr0yLMsDHkQIvXyVl+o+C0hW4QcB3R7X0d+GP5C/mncqB7KifiMabzheDeHAasUzeLCDwI6UnReEbqKEZ7+GV0fqyashFYJe9dilknNAK07+RoRG/AMtt4rbFBwKX3Ijbv9+S1n2j5uRzoiHRdsM0BNJ36HcsBIpK9I2dKJGB8V87YDtgsvhYXYdYFHWi/v7DAr6gz9MAaTRSkmv80Oxi4LLoB3GO5P+H8HD3zUxHp6F7bkW2usHHe/nARqUmMEJFlhgtEPkc2LS4qurm9AIcOJFRfya/lmLtWIhz7jPpHaC4EwCI8cNGt4HSvRD3ux/E6F2uOsPmcDRvtoZ1EONpHVENQhGzEVOlPvBYXY7SZ9qMH41s+kBjdKdMq0bUC4xljuYMjnN6IcTFwxCfKAR2RjgvB8ttyXvN+Wpyt0QbrRJsAj4jmT23TZWh9qWbgGNfygcQA7Us5Qw+0Q8PGLKTXDykNExeB4+ReE2xo4uED7eLDxCfa0cylNi3ScuAQANgAD9jagedmDHA63jaCAR8Xxd2nYWSfuZvbgrC0z4C5nHv7xp6/geM4RH8c0Oj5ch60+v+uolkZ8ccXxeWIQ032rbQNcSkxl5u15f71Bw+46AFwg+Zyq87YCLc90EIWArLuC40uXX5nbwgMCwWKKRDAFZM6KkKBAC44KKpAAFdU7qgsgAsGiioQwBWVOyoL4IKBogoEcEXljsoCuGCgqAIBXFG5o7IALhgoqkAAV1TuqCyACwaKKhDAFZU7KgvggoGiCgRwReWOygK4YKCoAgFcUbmjsgAuGCiqQABXVO6oLIALBooqEMAVlTsqC+CCgaIKBHBF5Y7KArhgoKgCAVxRuaOyAC4YKKpAAFdU7qgsgAsGiioQwBWVOyoL4IKBogoEcEXljsoCuGCgqAIBXFG5o7IALhgoqsAxf+OXHxfu8qINisqKK9B1zf1D03dO5hjAtSv0zCyenSV+iPmO7FVt4Prn17zNw63GjgXOB2dWFmZnYYobnGlwMLrsAK6Roto/Bo5r7uvvmXrMx7bxY4BzRRycyphJjsm9vpFjTA4RwDVSVP3HHAAb1x4GYAEmYCOftWc7h5S2H2Qml8jGgZmklikLP5djVAxw/u1+toXVqYBZADhggwFYgAnYgBHvMxg4HaMhl9n0oJkKmPMdY0Y5Jnpj6pvoTiXCAgyg2izABGx4xsVGhkFz3qc5U5nihnmVmKD2Azlzh1IysRfb3Z0GdBKjYnP0ouskohHlgI0p2m9Fuqur61GTu1GBqdZiUxnRDdgYG0Z3KhEWYobO43nmSMWPE+EQMUU5ohiRju7Tnk/upc1hC1EA6AhCjNkIRHbWm+nHVT4a1KXyRqw1HTnwRTfaKLPYP450gGe/oSu1IqOA4yAJOhY9VnPJtrDlKWC4mjKHDSlGA2c9M/C8KcoFK9AGzVL8D2LISgNuiqnzAAAAAElFTkSuQmCC"
                />
                <g
                  id="Groupe_11"
                  data-name="Groupe 11"
                  transform="translate(7.413 7.407)"
                >
                  <g id="Groupe_10" data-name="Groupe 10">
                    <path
                      id="Tracé_1046"
                      data-name="Tracé 1046"
                      d="M356.7,245.123,469.25,150.535h.056V68.378L239.394,67.05v83.484H370.306L261.7,244.583v80.391l.109-.1v3.19H491.721V245.906Z"
                      transform="translate(-239.394 -67.05)"
                      fill="url(#linear-gradient-2)"
                    />
                    <path
                      id="Tracé_1047"
                      data-name="Tracé 1047"
                      d="M239.394,67.05v83.486H285S254.518,108.312,239.394,67.05Z"
                      transform="translate(-239.394 -67.05)"
                      fill="#ad0f0a"
                    />
                    <path
                      id="Tracé_1048"
                      data-name="Tracé 1048"
                      d="M332.406,114.584H431.35L289.5,152.091Z"
                      transform="translate(-201.494 -31.099)"
                      fill="#ad0f0a"
                    />
                    <path
                      id="Tracé_1049"
                      data-name="Tracé 1049"
                      d="M347.05,168.439l-94.9,82.944,180.336-82.438Z"
                      transform="translate(-229.743 9.634)"
                      fill="#ad0f0a"
                    />
                  </g>
                </g>
              </g>
              <g
                id="Groupe_18"
                data-name="Groupe 18"
                transform="translate(195.386 89.13)"
              >
                <g
                  transform="matrix(1, 0, 0, 1, -35.33, -63.39)"
                  filter="url(#Rectangle_16)"
                >
                  <rect
                    id="Rectangle_16-2"
                    data-name="Rectangle 16"
                    width="83.93"
                    height="9.717"
                    transform="translate(43.34 156.88)"
                    fill="#413d41"
                  />
                </g>
                <g
                  transform="matrix(1, 0, 0, 1, -35.33, -63.39)"
                  filter="url(#Rectangle_17)"
                >
                  <rect
                    id="Rectangle_17-2"
                    data-name="Rectangle 17"
                    width="83.93"
                    height="13.035"
                    transform="translate(43.34 166.6)"
                    fill="#808082"
                  />
                </g>
                <g id="Groupe_17" data-name="Groupe 17">
                  <image
                    id="Rectangle_18"
                    data-name="Rectangle 18"
                    width="107.137"
                    height="286.283"
                    opacity="0.5"
                    xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAACjCAYAAAA5DhbaAAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAPaADAAQAAAABAAAAowAAAAB857DkAAAJHUlEQVR4Ae3diXLdxhGFYTHOvu+blijL+z+Ut9hV3mLHTjl2TPcH4tzMQLg0ZVEUAE5XtQYDDC7779MzACgSvLi8vHywd3vy5NHFGsPrr7+5CnexJ+gzcAFOiz+wU7uE3zT0AjJQbWt76YH+qjbily345qAb0CXcd2bAtI6/tnD7qAv2i8b/Z1/ANwG9AI1y4OLgvlveQurz75V/f26NB/zf8s/KP53bz6v9snxS3EmvxK4BDViAAvWDChRcAO2374ez23YuOLAflL9XzlLmFH9w50ovYJdKAgXVwvyo+j+e3TZPArSOZZ/Po+qH5W+Xv1H+Vvn75ZSf1L4zpVdgqRI1Bc8D+NPaXvOfzGOou0yO8xm4d6etK8Ul4ONyCZnsTqBnYHPVFwabkg0kmJ/N/vNqf1mu5fYnAVQFDNBn5HO0PlcZf1Lua31U/s9yYx3LWnH5UqEbdQPr6wkaLJgAgvxVuTbeAhvPAWROA4n7fFDK1zZlJch4XzPHa/Nqx7Rx2/8s1PWFBSsQsMB+U/7b8t/N27+u1v4oTP0ELnhq+pyARjlAzKXKqp3EZGzGGTOZA7dqK+oKlrpKFBTQP5T/cW4D/YvqSwhQqjrHuSldcFGsBbENmFudl2Mc7+xWoa9RFxAlwf559j9V+/tyilOXspmv4mqVCkjtnspY2xow8znJSNuOOW3fGnQDrPyoQ62oS02QD8sfzduAJYK6xrZzNZDL4PXXjMo3tluBnoEFCticUqLUpSJ1wQZYWUuCUpeUzFfntrDVXVXV/heyF4ZugH0WACBW4pQyZTlo+6irnCWGus67E9j6OpO9EPQKsFK1UCnlJ7M/nvvUlQxJySJF3ZTwudKtIbdr3xp6BZh6gCn6tPyv5X8plwD7s1idU7eG3I19K+gZmDKZw1FYGYP9e/nTcgkwr7NYtZef2v1y5qwPvs6eG3oFWLlGYcD/KNdKgP2As1gt524dunt7bug5RMHnDsvCpISfllM4wOYwYPPX13EOu7hqXt2/zwW9mMdgXJZcby1aYJ+WU3gN+JXDVlyTJfvpn21XgDOPzVvQFi3bKelW4c0AV3ynkrN91pp5nLJ2y2iBUtYuSaDdXmbR2ixwxXgzaAPLAFt93VS43rqzaoFzWbJoZQ5vSuGKa7JvLO9G5fbyZM6mrM1h89r8prDE+NxNAldcN1Z6TWWwnOKUz23lNyayxr5SuzbAZvFqVVbG5rI5DNgly7XaJSwKb1blivFGSgPIo6InI6UNNg8PgDc/jyvGk51V+ozKVDV/eRaurNSSs2mFK77JzkLPx1uVLVRAKUxtffN48wtXxdjZKvTKiq2EozJg27mn3vTlqaOdO6vQzTFAytdjoRuPlDWVfYvH8V2UdMV5snPQQBzLzUi+i6m8s1pbvKzqxu0K/BnoM6XtOkxpTvWo/Mz5dWzzdi5oyildaprPlKawsnbf7ZpMZeN2pXLFu3qdBiEZoClKWdA8z8e7W7Er9pN1Si9Km5pUDbTWJSpzeXcKV+yTddDzPjC57QStpKNyO5eN2yX4EhpEStulynymMG9vN3cJWwyTnaDn0rbTvtxrm8OAtVTe9QJW8U92gp77UTrQ1AWszbOyMcdQukAYGPOZopQ1pwG3Ki8TVYf3ZS1AVM712UoNGHigjd+1yhX/1XW6mc9R2mUJNGCuLxlJ0q7BA1E8k4L6rdLAo/Ju78DAtXYO2py2cIHWtqt2dfdtS2hqWrmBUjjAKe1dl3XxTBZoMJnPWbmpzHPbaewxoFcWsRY685nSAU5bu/ZpYBgQnms0dZW2Nk9UtTnZc/1QS056ya2Y1nz1ywbaQdBKOPMabOZybU4f+lW1W1QasNjiywTUof9bC529gcoHfVkHviiXkK3O68T6ecXopwa5uP0wXRJQm1e2hDbAQJD/Kf93+cflEmGubx0a7L/KPyn/rFwSwKsAbJMFOtkAbKCTPih/p5z5INDgUwm1uRlL/KDFLm7xEw1Pp3iga/+UDQrL0Iflb5cD/Kjcpcsc3yJwhTUZ8MQP+K1yLR77qT3Z9JP982XLAma19pDhm4D5dq9HS/tT2lsEj9LA2kp9r/qd4n555ZzSNXY6mcqAjQO7ReAKa7KAm8PAP519XWmnzGpTs71kKWn9qFybmzbg1M5irKy5/vqvKM3g1AQZ37rCFWpnURx8/PpfRlvclvq0LZd0R9t0gLOpzS+hXe0qoHO/a9nAZ+zu2iVsAJTwvbNnlG4UTlmn3VNybl7e924hm4GV+/24ZDUKuwlxM+K2c/md0K1funKpWrs5cbNi/zO/VUtlNyOAj3QbWjin67WblAcXjx8/jIJUBuynDR6WP55bCdjrA8cbFbsHj/fL3Y5Oarf33kulgf+t3A/KeejY26NlhTzdf3ti9D0BfJMFOmpbxNonLcCPyv0f9Z6+iVDhTo/Enhjx4Apj95Rlp2y0ixmF85/yTnbcuK2ZRSyPlWLzTQ9TUsx4urijdO2fLNmQGceoy528B+gK8xSz+FuFHZtsCW1nwNPKUutbVVrsiTOxp3XsZGvQOZgT1tqM2VJ74zhl5t7ZgL4vkg+lh9IHzsAo7wOL26ENpbt0HLgzlD6wuB3aULpLx4E7Q+kDi9uhDaW7dBy4M5Q+sLgd2lC6S8eBO0PpA4vboQ2lu3QcuDOUPrC4HdpQukvHgTtD6QOL26ENpbt0HLgzlD6wuB3aULpLx4E7Q+kDi9uhDaW7dBy4M5Q+sLgd2lC6S8eBO0PpA4vboQ2lu3QcuDOUPrC4HdpQukvHgTtD6QOL26ENpbt0HLgzlD6wuB3aULpLx4E7Q+kDi9uhDaW7dBy4M5Q+sLgd2lC6S8eBO0PpA4vboQ2lu3QcuDOUPrC4Hdp1L2zKiwqXbfcBG+ksY0x/Nbw16JyQNi8R1jJvg9qaibWNM7Gn7eJdQmeQty56CWFe+u8VlMwasGVocSZm8eMIU21eWQvtoGwZ7GRvX/T+e6+uY3t6x6C4xZ/3heLCN1mgkw2ZMdAL/r32/V79oYK86L+4xx8qyCvtJGNLlkpVxipVeRNu/KGCSsJkp/d737u3PicDzdufXZriWy3phL1s21LPtXv8oYJTeS/TNau+3L2r/rk/VPA1lQ0m66bNlN4AAAAASUVORK5CYII="
                  />
                  <g
                    id="Groupe_16"
                    data-name="Groupe 16"
                    transform="translate(8.011 8.241)"
                  >
                    <g id="Groupe_15" data-name="Groupe 15">
                      <g
                        id="Groupe_13"
                        data-name="Groupe 13"
                        transform="translate(0.22)"
                      >
                        <path
                          id="Tracé_1050"
                          data-name="Tracé 1050"
                          d="M184.861,151.776h83.927V66.525C183.538,70.061,184.861,151.776,184.861,151.776Z"
                          transform="translate(-184.859 -66.525)"
                          fill="url(#linear-gradient-3)"
                        />
                      </g>
                      <g
                        id="Groupe_14"
                        data-name="Groupe 14"
                        transform="translate(0 108.224)"
                      >
                        <rect
                          id="Rectangle_19"
                          data-name="Rectangle 19"
                          width="83.93"
                          height="154.154"
                          fill="url(#linear-gradient-4)"
                        />
                      </g>
                    </g>
                  </g>
                </g>
              </g>
              <g
                id="Groupe_23"
                data-name="Groupe 23"
                transform="translate(551.922 90.887)"
              >
                <image
                  id="Rectangle_20"
                  data-name="Rectangle 20"
                  width="107.137"
                  height="282.77"
                  transform="translate(0)"
                  opacity="0.5"
                  xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAChCAYAAAB0xrfRAAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAPaADAAQAAAABAAAAoQAAAAAGJ+OEAAAIWElEQVR4Ae3da5PcthGFYa0d24ljV1yOP6TKlj/k//+lVBRZzv1+v2rTD8UzBc5Aq5W0kkgsuqoFAsRw8fZpAFwVZ3l1fX39oGdff/3VVa/9KG2PHz/pgxXA1Tl0AxvolEfhDexS9uA30CswyPcaVz8KOFD+tPHrc/AT9AoM9v3yDxpX17538MD+r8b6n8bVn7bgC3Sj8Heqw0flH5d/f3V17XtWPAr/t8b5r/K/rf73ta79pDiYGDUpDPjz8i/W8tMqgUftvSkeYCkN+C/lvy//bTlLqlN8sauHD7+MggIA+IflX5Y/XEsB0C4gewOuIS0GXEpTFvC35d+s5e+q1H5S+yalgf+4/Efl1P6wPAGqw91YlP53jYjKv1xHJsX/UP7ncll6skAHxqIllT8ppzDgr8p/UA46KV6HuzHQUhj0n9ZR/bFKDFgwhU/fZYFSMidACYTOUprCgD8rb+d1VXdjgTafGXBjN14sF0JF6Tq3WCIiOs5Rl7vA3qFriKfxGnursHMnO4d2IuApRap17XuyJWVrQBljxp3yYqw96HTKh3pl+uylfKkxis69swl9XySfSk+lB47ATO+Bxd2gTaU34Ri4MpUeWNwN2lR6E46BK1PpgcXdoE2lN+EYuDKVHljcDdpUehOOgStT6YHF3aBNpTfhGLgylR5Y3A3aVHoTjoErU+mBxd2gTaU34Ri4MpUeWNwN2qhKtw/ebIBVRoNuYc+PT/AjQQcSkwfn4uo5t4CPBo3Hs3GeWPako1I94HU4TnpHSeoC/W7599ZSffPI5AhKA2ZKcJ5hBRxXD/QD32IYAbqYTnP23igNmlH6Xs3pQAec4vEsYpkGc58WrVGMqvELplEWsguwmxom9E3RGencqEr7Xkf8Qq/RoAPaK0/wI0EH1BfTfK8yrp5zC/ho0AB9p9L3Ln0jT6ke8Doc57esKEldoP8s/8daqmtPnyHuyMAwJThfPwQcVw/0A18eHyW9o+K9UbqEXAz4vZrTqKM2cIrHs4g5v9go6R2egPfK9BliITvBNActdNP87HA0pS8Aew0TuheVEdum0iOq2mOaSveiMmLbVHpEVXtMU+leVEZsm0qPqGqPaSrdi8qIbVPpEVXtMU2le1EZsW0qPaKqPaapdC8qI7ZNpUdUtcc0le5FZcS2qfSIqvaYptK9qIzYNpUeUdUe01S6F5UR26bSI6raYxpR6RufLBKEkaBb2PPjjeCjQAfyhU8LjqQ06Fs9FzoKdFT2LKgH2/PIs2e+1bWnTx0ef06DYVHZs93emORlQsoWennWu9qGWMiS2p7gpzLgv5aDFoQhv84Auk1twMAFYKN01Rc7+uodlanZpjZw0NTP8951+MyODA24hbZwgfWiMEqrJ7VP87nahpjTbWq/cD4fHToqg5bagKmcRaw7n+v8YZVOakdlKzVgb0Xzzjv17nyu9sNCGztw0JnL3nvHQbeL2GY+17lDQkdlq7IUpiqFvdqRn0Prv7Gjrt5RGbS5TGHvr/RKR2m+WbmrvrEjQgOmcu7AKBuVwVNeMPS5SG1tR4NOamcBo3JSOyqbz9mfL1L7qNDnKkvrpLbt6rlbFWB2JKWjcm45zV2wvyn3Mt7z1D69hbjObewo0AFOWlPUPP51+a/KQWfVTmpXU9+OAm30SWsLFVUB/6LcC3lBU/6U2u1Ltqt9Y0eApjJgCtqKKCqlAf+8nNKCsLkhqfpzbe/Q58DUpCrgJ+Wgo7KASP/nzuU6t9ieoTOPqSxtzWMLl3T+phx0VJbyL5zL1WexPUMbYIBB2YcDDJragrDZpm6ay9V3sb1CJ63ddUlbNyAWLur+bC2prP10M3Ib4Oq/y306wNmPLVzmrfn7uJzKFM++nF8hq+l2tjelW2AK5wakBT5Pa1PghYtXGw5/U3MPBpa1WxNgW9O35VKayo7b1XpZvG6b1vXZxfYADTgKS1X/9dMCP6r6T8tBm9fmsSx4JeD63PLXU5Xvwlp17a/5VTEpTdVH5T9ZS2nt1nPzq2PVX9reldKtuhSzD/s1MYsWQClN4UflSWvbk0y41U1I9eva24YOrDLqSlUw9uHcXlqhpTMXgMzj1waua7219AbJLFQcMAB7bP4TwL5L0Ser575aMKLwK8/jusbJ3qTSAY26gc1iBcReS137LljQXADcbQmIORyFn77sSl2fvbC7hg6oH3QOSyWDB2Gxyu/D0jfAjgVBMAQlvzm91hyu62zsdaBbQBdNXZk0VlLWQgUACPWoSE2Q0jipLBBR12eWdK7ypW4+qv+NdhN0lDovXbAFbM8HNouUgVuosjKDsijZb6U0B68t6uovUK7het3/0dT+qtaDbiEcB0R5DptzBsgpkzlr8NSVylmspC5g7jiw+mT/fSPq1vVPdg4d4ABQipuLzvn7usoWsgXNipxUboGlNEhlFinn9RUg13HdN6JuXfdkLTQYP9APbxccKrEPnhXLwNpgJIUNnlrmLQfkZsPnbTvSl2vLIuXntKl8p3O3rt21QLcKG4hBmX/mHDNwffUzyKQu0Lh5ywOdErxj5wTFZy9gq+3O565r9izQzlEZkIEBtl8y6nxc/n65PpSNqvoGum1LO8BABjRpnMx6a7A1lsWurq+vlz/eXzVQH5V/Uv55+Rdr+WmVH5a/V27ORemoHajMfXCO9eOBzHwVOMBvHdbPZM9T2jmDp7JACIhFzIANHlQ8YIFLqW880+edwtZ4FluUduRVDVVQE6BFK66unSUlgbfewjkOZD7zzlQ1gHM7QTuxggceKFdnysCkBMhSz/HSeBf3ycuF7vifDbRrr+AOW1j11kCylEtlr5DL4Jp/LqBzroFP06Y8CuBm0Gvl/zKiHfTBOahhAAAAAElFTkSuQmCC"
                />
                <g
                  id="Groupe_22"
                  data-name="Groupe 22"
                  transform="translate(7.473 7.145)"
                >
                  <g id="Groupe_21" data-name="Groupe 21">
                    <g
                      id="Groupe_19"
                      data-name="Groupe 19"
                      transform="translate(0 84.59)"
                    >
                      <rect
                        id="Rectangle_21"
                        data-name="Rectangle 21"
                        width="83.934"
                        height="9.717"
                        fill="#413d41"
                      />
                    </g>
                    <g
                      id="Groupe_20"
                      data-name="Groupe 20"
                      transform="translate(0 94.307)"
                    >
                      <rect
                        id="Rectangle_22"
                        data-name="Rectangle 22"
                        width="83.934"
                        height="13.035"
                        fill="#808082"
                      />
                    </g>
                    <path
                      id="Tracé_1051"
                      data-name="Tracé 1051"
                      d="M471.358,128.144h-83.93V199.7h0v81.924c74.913-3.1,82.978-66.581,83.825-81.924h.105Z"
                      transform="translate(-387.428 -20.581)"
                      fill="url(#linear-gradient-5)"
                    />
                    <rect
                      id="Rectangle_23"
                      data-name="Rectangle 23"
                      width="83.93"
                      height="83.818"
                      fill="url(#linear-gradient-6)"
                    />
                  </g>
                </g>
              </g>
              <path
                id="Tracé_1052"
                data-name="Tracé 1052"
                d="M330.741,213.114a15.172,15.172,0,1,1-15.173-15.169A15.172,15.172,0,0,1,330.741,213.114Z"
                transform="translate(106.143 130.244)"
                fill="url(#radial-gradient)"
              />
              <g
                id="Groupe_24"
                data-name="Groupe 24"
                transform="translate(423.982 51.241)"
              >
                <path
                  id="Tracé_1053"
                  data-name="Tracé 1053"
                  d="M329.57,45.8h6.159V68.36H329.57V65.977a12.254,12.254,0,0,1-3.616,2.271,10.934,10.934,0,0,1-3.932.694,11.715,11.715,0,0,1-11.694-11.82,11.568,11.568,0,0,1,3.356-8.566,11.616,11.616,0,0,1,12.3-2.568,11.315,11.315,0,0,1,3.581,2.3ZM323.1,50.444a6.5,6.5,0,0,0-4.744,1.856,6.372,6.372,0,0,0-1.888,4.758,6.508,6.508,0,0,0,6.655,6.7A6.629,6.629,0,0,0,327.93,61.9a6.476,6.476,0,0,0,1.911-4.863,6.292,6.292,0,0,0-1.911-4.768A6.709,6.709,0,0,0,323.1,50.444Z"
                  transform="translate(-310.328 -36.509)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1054"
                  data-name="Tracé 1054"
                  d="M327.514,45.8h5.278v2.842a6.218,6.218,0,0,1,2.278-2.554,5.837,5.837,0,0,1,3.112-.869,6.181,6.181,0,0,1,2.5.581l-1.918,4.874a4.478,4.478,0,0,0-1.781-.5,2.824,2.824,0,0,0-2.4,1.616q-.98,1.618-.982,6.346l.023,1.1V68.36h-6.112Z"
                  transform="translate(-297.33 -36.509)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1055"
                  data-name="Tracé 1055"
                  d="M338.532,40.815h6.159v8.316h3.653v4.874h-3.653V71.691h-6.159V54.005h-3.158V49.131h3.158Z"
                  transform="translate(-291.385 -39.84)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1056"
                  data-name="Tracé 1056"
                  d="M370.6,40.591h6.159v31.27H370.6V69.477a12.253,12.253,0,0,1-3.616,2.271,10.934,10.934,0,0,1-3.932.694,11.715,11.715,0,0,1-11.694-11.82,11.569,11.569,0,0,1,3.356-8.566,11.616,11.616,0,0,1,12.3-2.568,11.315,11.315,0,0,1,3.581,2.3Zm-6.474,13.353a6.494,6.494,0,0,0-4.744,1.856,6.379,6.379,0,0,0-1.888,4.758,6.508,6.508,0,0,0,6.655,6.7,6.626,6.626,0,0,0,4.811-1.855,6.476,6.476,0,0,0,1.911-4.863,6.292,6.292,0,0,0-1.911-4.768A6.706,6.706,0,0,0,364.122,53.944Z"
                  transform="translate(-279.299 -40.01)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1057"
                  data-name="Tracé 1057"
                  d="M394.446,58.718H374.661a5.934,5.934,0,0,0,2.29,3.825,7.6,7.6,0,0,0,4.747,1.419,8.585,8.585,0,0,0,5.933-2.218l5.19,2.241a11.96,11.96,0,0,1-4.647,3.741,15.582,15.582,0,0,1-6.43,1.215,13.336,13.336,0,0,1-9.407-3.348A10.938,10.938,0,0,1,368.7,57.2a11.28,11.28,0,0,1,3.622-8.574,12.718,12.718,0,0,1,9.08-3.411,13.211,13.211,0,0,1,9.428,3.411,11.779,11.779,0,0,1,3.632,9.008Zm-6.158-4.458a5.724,5.724,0,0,0-2.408-3.07,7.423,7.423,0,0,0-4.17-1.18,7.823,7.823,0,0,0-4.519,1.326,7.4,7.4,0,0,0-2.259,2.924Z"
                  transform="translate(-266.175 -36.509)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1058"
                  data-name="Tracé 1058"
                  d="M402.058,48.953l-3.811,3.5q-2.324-2.113-4.219-2.113a2.824,2.824,0,0,0-1.625.4,1.145,1.145,0,0,0-.214,1.844,6.9,6.9,0,0,0,1.839,1.05l2.255,1.034a13.29,13.29,0,0,1,4.9,3.3,6.157,6.157,0,0,1,1.331,3.941,6.276,6.276,0,0,1-2.4,5.016,9.7,9.7,0,0,1-6.44,2.013,10.572,10.572,0,0,1-8.571-3.857l3.79-3.794a8.678,8.678,0,0,0,2.538,1.874A5.946,5.946,0,0,0,394,63.88a3.27,3.27,0,0,0,1.964-.539,1.525,1.525,0,0,0,.745-1.24q0-1.312-2.685-2.554l-2.076-.952Q386,55.834,386,51.689a5.787,5.787,0,0,1,2.246-4.574,8.592,8.592,0,0,1,5.741-1.9,10.751,10.751,0,0,1,4.5.962A9.822,9.822,0,0,1,402.058,48.953Z"
                  transform="translate(-253.779 -36.509)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1059"
                  data-name="Tracé 1059"
                  d="M400.828,40.26a3.952,3.952,0,0,1,2.779,1.077,3.444,3.444,0,0,1,1.157,2.613,3.4,3.4,0,0,1-1.147,2.584,3.889,3.889,0,0,1-2.745,1.068,3.942,3.942,0,0,1-2.8-1.091,3.486,3.486,0,0,1-1.159-2.643,3.351,3.351,0,0,1,1.147-2.55A3.945,3.945,0,0,1,400.828,40.26Zm-3.081,9.291H403.9v22.56h-6.158Z"
                  transform="translate(-244.842 -40.26)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1060"
                  data-name="Tracé 1060"
                  d="M422.683,45.8h6.137V65.125q0,5.725-2.5,8.42-3.362,3.651-10.129,3.648a19.106,19.106,0,0,1-6.068-.829,11.026,11.026,0,0,1-4.152-2.436,9.827,9.827,0,0,1-2.5-3.906h6.792a5.682,5.682,0,0,0,2.322,1.438,10.342,10.342,0,0,0,3.363.488,9.584,9.584,0,0,0,3.992-.7,4.506,4.506,0,0,0,2.13-1.827,8.554,8.554,0,0,0,.622-3.857,10.274,10.274,0,0,1-3.407,2.148,11.717,11.717,0,0,1-4.038.652,11.585,11.585,0,0,1-8.348-3.276,11.029,11.029,0,0,1-3.406-8.3,11.048,11.048,0,0,1,3.611-8.625A11.729,11.729,0,0,1,418.9,45.936a12.762,12.762,0,0,1,3.78,2.353ZM416.3,50.506a6.712,6.712,0,0,0-4.805,1.795,5.951,5.951,0,0,0-1.9,4.51,6.027,6.027,0,0,0,1.941,4.623,6.872,6.872,0,0,0,4.872,1.806,6.605,6.605,0,0,0,4.726-1.762A6.077,6.077,0,0,0,423,56.851a6,6,0,0,0-1.872-4.581A6.757,6.757,0,0,0,416.3,50.506Z"
                  transform="translate(-239.887 -36.509)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1061"
                  data-name="Tracé 1061"
                  d="M421.444,45.8H427.6v2.313a14.982,14.982,0,0,1,3.8-2.26,9.886,9.886,0,0,1,3.481-.634,8.81,8.81,0,0,1,6.195,2.343,7.655,7.655,0,0,1,2.141,5.889V68.36h-6.091V58.483a23.064,23.064,0,0,0-.393-5.366,3.648,3.648,0,0,0-1.373-2.02,4.059,4.059,0,0,0-2.418-.694,4.773,4.773,0,0,0-3.209,1.147,6.041,6.041,0,0,0-1.856,3.182,23.483,23.483,0,0,0-.27,4.579V68.36h-6.158Z"
                  transform="translate(-226.287 -36.509)"
                  fill="#fff"
                />
              </g>
              <g
                id="Groupe_25"
                data-name="Groupe 25"
                transform="translate(208.446 377.294)"
              >
                <path
                  id="Tracé_1062"
                  data-name="Tracé 1062"
                  d="M271.576,251.083a20.424,20.424,0,0,1-3.17,11.606,23.331,23.331,0,0,1-8.567,7.63,41.789,41.789,0,0,1-12.6,4.138,89.886,89.886,0,0,1-15.412,1.256h-12.1a5.3,5.3,0,0,0-3.024.869,2.751,2.751,0,0,0-1.3,2.4v20.161a2.363,2.363,0,0,1-1.08,1.907,4.068,4.068,0,0,1-2.522.818H191.211a4.064,4.064,0,0,1-2.522-.818,2.363,2.363,0,0,1-1.08-1.907V235.385a7.388,7.388,0,0,1,1.154-4.085,9.825,9.825,0,0,1,3.023-3,14.8,14.8,0,0,1,4.034-1.8,16.2,16.2,0,0,1,4.321-.6h31.684a84.211,84.211,0,0,1,15.482,1.365,41.832,41.832,0,0,1,12.674,4.361,23.436,23.436,0,0,1,8.5,7.789A21.059,21.059,0,0,1,271.576,251.083Zm-27.942-.109a8.282,8.282,0,0,0-3.24-7.029q-3.24-2.458-9.289-2.457H206.765a10.253,10.253,0,0,1,2.592.383,9.808,9.808,0,0,1,2.663,1.143,7.769,7.769,0,0,1,2.09,1.909,4.153,4.153,0,0,1,.864,2.561v9.372a2.826,2.826,0,0,0,1.366,2.452,5.4,5.4,0,0,0,3.1.929H231.1q5.9,0,9.216-2.4A7.958,7.958,0,0,0,243.634,250.974Z"
                  transform="translate(-187.609 -225.904)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1063"
                  data-name="Tracé 1063"
                  d="M325.629,301.884H305.32q-4.033,0-5.759-2.835l-14.69-21.8a4.541,4.541,0,0,0-3.89-1.744H262.115a8.123,8.123,0,0,1,5.689,1.906,5.371,5.371,0,0,1,2.088,3.867v17.985a2.086,2.086,0,0,1-1.008,1.851,4.177,4.177,0,0,1-2.592.766H246.559a4.061,4.061,0,0,1-2.519-.818,2.291,2.291,0,0,1-1.08-1.8V235.405a7.975,7.975,0,0,1,3.743-6.7,14.737,14.737,0,0,1,8.785-2.673h30.534a86.833,86.833,0,0,1,15.338,1.308,43.742,43.742,0,0,1,12.818,4.252,24.728,24.728,0,0,1,8.859,7.684,19.783,19.783,0,0,1,3.312,11.608,19.239,19.239,0,0,1-3.89,11.767q-3.889,5.23-11.52,8.5c-.771.364-1.177.8-1.226,1.309a1.412,1.412,0,0,0,.362,1.2L328.221,298.5a2.244,2.244,0,0,1,.43,1.2,1.859,1.859,0,0,1-.934,1.526A3.58,3.58,0,0,1,325.629,301.884Zm-27.077-51.113a7.675,7.675,0,0,0-3.529-6.813,16.237,16.237,0,0,0-9.145-2.343H261.107a8.533,8.533,0,0,1,5.761,1.853,5.229,5.229,0,0,1,2.16,3.922v8.827a2.876,2.876,0,0,0,1.224,2.29,4.788,4.788,0,0,0,3.1.98h12.53a17.535,17.535,0,0,0,9.145-2.127A7.152,7.152,0,0,0,298.552,250.771Z"
                  transform="translate(-145.745 -225.81)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1064"
                  data-name="Tracé 1064"
                  d="M299.869,299.205V235.452a8.061,8.061,0,0,1,3.743-6.813,14.737,14.737,0,0,1,8.785-2.673H323.92a3.833,3.833,0,0,1,2.592.766,2.357,2.357,0,0,1,1.008,1.96v70.513a2.257,2.257,0,0,1-1.008,1.851,3.5,3.5,0,0,1-2.592.875H303.469a4.055,4.055,0,0,1-2.52-.818A2.363,2.363,0,0,1,299.869,299.205Z"
                  transform="translate(-102.703 -225.857)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1065"
                  data-name="Tracé 1065"
                  d="M326.929,299.143V235.385a8.294,8.294,0,0,1,3.6-6.646,13.989,13.989,0,0,1,8.929-2.835h4.754a17.277,17.277,0,0,1,3.743.492,9.342,9.342,0,0,1,4.465,2.891q8.5,10.024,15.268,18.089,4.176,4.9,6.553,7.793t4.537,5.339c1.44,1.633,2.64,3.037,3.6,4.194s1.535,1.856,1.728,2.074c0,.146.191.216.576.216.479,0,.72-.179.72-.543V235.385a7.95,7.95,0,0,1,3.889-6.864,15.391,15.391,0,0,1,8.785-2.617h9.217a4.178,4.178,0,0,1,2.592.766,2.887,2.887,0,0,1,1.008,2.069v70.3a2.8,2.8,0,0,1-1.008,1.96,4.2,4.2,0,0,1-2.592.875H391.018a6.013,6.013,0,0,1-4.9-2.074q-8.641-10.027-15.554-17.98-4.181-4.8-6.625-7.686t-4.61-5.337q-2.158-2.453-3.6-4.143c-.961-1.124-1.537-1.8-1.728-2.016a1.314,1.314,0,0,0-.722-.327c-.481,0-.72.184-.72.544v36.293a2.275,2.275,0,0,1-1.15,1.96,4.594,4.594,0,0,1-2.594.766h-18.29a3.994,3.994,0,0,1-2.448-.875A2.4,2.4,0,0,1,326.929,299.143Z"
                  transform="translate(-82.236 -225.904)"
                  fill="#fff"
                />
                <path
                  id="Tracé_1066"
                  data-name="Tracé 1066"
                  d="M463.859,225.9a4.284,4.284,0,0,1,2.663.818,2.368,2.368,0,0,1,1.08,1.907v12.207a2.3,2.3,0,0,1-1.08,1.96,4.477,4.477,0,0,1-2.663.766H430.444a9.777,9.777,0,0,1,5.689,1.742q2.519,1.744,2.522,3.922v49.917a2.036,2.036,0,0,1-1.154,1.851,4.165,4.165,0,0,1-2.592.762H414.89a4.158,4.158,0,0,1-2.592-.762,2.029,2.029,0,0,1-1.152-1.851V246.831a2.75,2.75,0,0,0-1.3-2.4,5.287,5.287,0,0,0-3.024-.869H385.942a4.563,4.563,0,0,1-2.592-.766,2.269,2.269,0,0,1-1.154-1.96v-5.559a7.087,7.087,0,0,1,1.082-3.813,10.2,10.2,0,0,1,2.879-3,13.832,13.832,0,0,1,4.034-1.9,15.934,15.934,0,0,1,4.537-.657Z"
                  transform="translate(-40.436 -225.904)"
                  fill="#fff"
                />
              </g>
            </g>
          </svg>
        </div>

        <div
          class="
            flex flex-col
            lg:flex-row
            justify-start
            items-center
            self-start
          "
        >
          <p class="uppercase text-gray-200 text-3xl pl-2">Expertise Péi</p>
          <div class="hidden lg:block border h-32 border-gray-200 mx-12"></div>
          <div class="lg:hidden border w-32 border-gray-200 my-12"></div>
          <p class="text-gray-200 text-2xl text-width text-center">
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
            nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam
            erat, sed diam voluptua.
          </p>
        </div>
        <div class="flex flex-col justify-center items-center py-6">
          <div class="flex flex-col lg:flex-row justify-center items-center">
            <home-page-card :data="enseignes" class="m-5"></home-page-card>
            <home-page-card :data="vehicules" class="m-5"></home-page-card>
            <home-page-card :data="signaletique" class="m-5"></home-page-card>
          </div>
          <div class="flex flex-col lg:flex-row justify-center items-center">
            <home-page-card :data="packaging" class="m-5"></home-page-card>
            <home-page-card :data="plv" class="m-5"></home-page-card>
          </div>
        </div>
        <div
          class="
            flex flex-col
            lg:flex-row
            justify-center
            items-center
            self-end
            pb-20
          "
        >
          <p class="uppercase text-gray-200 text-3xl">Besoin d'un devis ?</p>
          <div class="hidden lg:block border h-32 border-gray-200 mx-12"></div>
          <div class="lg:hidden border w-32 border-gray-200 my-12"></div>
          <router-link
            to="/contact"
            class="
              bg-primary-dark
              rounded
              h-12
              w-32
              flex
              justify-center
              items-center
            "
          >
            <p class="text-gray-200 text-2xl">Allons</p>
          </router-link>
        </div>
        <div v-for="block in currentPage.blocks" :key="block.id" class="">
          <block-preview :block="block"></block-preview>
        </div>
      </div>
      <div v-if="currentPage.gallery.length > 0" class="px-4">
        <image-gallery :images="currentPage.gallery"></image-gallery>
      </div>
    </div>
  </div>
</template>

<script>
import indexMixin from "./mixins/indexMixin.js";
import HomePageCard from "./HomePageCard.vue";

export default {
  mixins: [indexMixin],
  components: {
    HomePageCard,
  },
  data() {
    return {
      enseignes: {
        imageUrl: "/images/enseignes.jpg",
        imageAlt: "Enseigne avec lettres en volume",
        link: "/enseignes",
        text: "Enseignes",
      },
      vehicules: {
        imageUrl: "/images/vehicules.jpg",
        imageAlt: "Total Covering IZIprint",
        link: "/vehicules",
        text: "Véhicules",
      },
      signaletique: {
        imageUrl: "/images/signaletique.jpg",
        imageAlt: "Autocollants Signalétique",
        link: "/signaletique",
        text: "Signalétique",
      },
      packaging: {
        imageUrl: "/images/packaging.jpg",
        imageAlt: "Packaging personnalisé",
        link: "/packaging",
        text: "Packaging",
      },
      plv: {
        imageUrl: "/images/plv.jpg",
        imageAlt: "Plv lumineuse",
        link: "/plv",
        text: "PLV",
      },
    };
  },
};
</script>

<style scoped>
@media (min-width: 1024px) {
  .bg {
    background-image: url("../../../assets/images/background.svg");
  }
  .text-width {
    width: 600px;
  }
}
</style>