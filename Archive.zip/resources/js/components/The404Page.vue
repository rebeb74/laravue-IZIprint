<template>
    <div class="h-1/2 w-full flex justify-center items-center flex-col">
        <div class="text-primary-dark text-4xl pb-10">
            Page introuvable !
        </div>
        <i class="fas fa-bomb text-9xl text-primary-dark ml-6"></i>
        <router-link to="/" class="rounded py-2 px-4 bg-primary-dark text-gray-200 mt-10">
        Retour au site
        </router-link>
    </div>
</template>